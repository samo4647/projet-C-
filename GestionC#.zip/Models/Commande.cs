
using System;
using System.Collections.Generic;

namespace GestionCommandesNSA.Models
{
    public class Commande
    {
        public int Id { get; set; }
        public DateTime DateCommande { get; set; }
        public decimal Montant { get; set; }
        public int ClientId { get; set; }
        public Client Client { get; set; }
        public ICollection<ProduitCommande> Produits { get; set; }
    }

    public class ProduitCommande
    {
        public int ProduitId { get; set; }
        public Produit Produit { get; set; }
        public int Quantite { get; set; }
    }
}
